/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utils;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;


/**
 *
 * @author Admin
 */
public class MyUtils {
    // Scanner dùng để nhập dữ liệu từ bàn phím
    private static final Scanner scanner = new Scanner(System.in);
     /**
     * Nhập một số nguyên từ bàn phím.
     *
     * @param message Thông báo nhập dữ liệu
     * @param isSizeCheck Nếu true thì chỉ chấp nhận số nguyên dương (>0)
     * @return Giá trị số nguyên hợp lệ
     */
    public static int inputInteger(String message, boolean isSizeCheck) {
        while (true) {
            System.out.print(message);
            String input = scanner.nextLine().trim();
            try {
                int number = Integer.parseInt(input);
                // Kiểm tra kích thước mảng phải lớn hơn 0
                if (isSizeCheck && number <= 0) {
                    System.out.println("Please enter a positive number > 0!");
                    continue;
                }
                return number;
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid integer number!");
            }
        }
    }
    /**
     * Sinh mảng ngẫu nhiên gồm n phần tử.
     * Giá trị các phần tử nằm trong khoảng [-n, n].
     *
     * @param n Kích thước mảng
     * @return Mảng số nguyên ngẫu nhiên
     */
    public static int[] generateRandom(int n) {
        int[] array = new int[n];
        Random random = new Random();
        for (int i = 0; i < n; i++) {
            array[i] = random.nextInt(2 * n + 1) - n;
        }
        return array;
    }
    /**
     * Hiển thị toàn bộ mảng ra màn hình.
     *
     * @param array Mảng cần hiển thị
     */
    public static void displayArray(int[] array) {
        System.out.println(Arrays.toString(array));
    }

}
