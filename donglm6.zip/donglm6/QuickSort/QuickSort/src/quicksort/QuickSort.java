/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package quicksort;

import utils.MyUtils;

/**
 *
 * @author Admin
 */
public class QuickSort {
    // Đếm số lần thực hiện Partition để hiển thị từng bước
    private static int step = 1;

    /**
     * Thực hiện một lần Partition của Quick Sort.
     *
     * Ý tưởng:
     * - Chọn phần tử ở giữa làm Pivot.
     * - Dùng hai con trỏ i và j:
     *      + i đi từ trái sang phải.
     *      + j đi từ phải sang trái.
     * - Nếu tìm được:
     *      + array[i] >= Pivot
     *      + array[j] <= Pivot
     *   thì hoán đổi hai phần tử.
     * - Khi i vượt j thì kết thúc Partition.
     *
     * Sau Partition:
     * - Các phần tử bên trái Pivot sẽ nhỏ hơn hoặc bằng Pivot.
     * - Các phần tử bên phải Pivot sẽ lớn hơn hoặc bằng Pivot.
     *
     * @param array Mảng cần sắp xếp
     * @param left Chỉ số đầu của đoạn mảng
     * @param right Chỉ số cuối của đoạn mảng
     * @return Vị trí bắt đầu của nửa mảng bên phải sau khi Partition
     */

    private static int quickSort(int[] array, int left, int right) {
        int pivot = array[left + (right - left) / 2];
        int i = left;
        int j = right;

        // In thông tin phân vùng và giá trị chốt (pivot) hiện tại ra màn hình để chứng minh bước chạy
        System.out.printf("Step %d [Partition zone: index %d to %d | Pivot value = %d]:\n",
                step++, left, right, pivot);

        while (i <= j) {
            while (array[i] < pivot) {
                i++;
            }
            while (array[j] > pivot) {
                j--;
            }
            if (i <= j) {
                if (i < j && array[i] != array[j] ) { // Chỉ in thông báo nếu thực sự diễn ra hành động tráo đổi giữa 2 chỉ số khác nhau
                    System.out.printf("   -> Swap array[%d](%d) and array[%d](%d)\n",
                            i, array[i], j, array[j]);
                }
                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
                i++;
                j--;
            }
        }
        // In cấu trúc mảng tạm thời ngay sau khi kết thúc lượt phân vùng này
        System.out.print("   => State after partition loop: ");
        MyUtils.displayArray(array);

        return i; // Trả về điểm phân rã ranh giới mới
    }
    /**
     * Hàm Quick Sort sử dụng đệ quy.
     *
     * Sau mỗi lần Partition:
     * - Đệ quy sắp xếp nửa bên trái.
     * - Đệ quy sắp xếp nửa bên phải.
     *
     * @param array Mảng cần sắp xếp
     * @param left Chỉ số đầu
     * @param right Chỉ số cuối
     */

    public static void sort(int[] array, int left, int right) {
        // Không cần sắp xếp nếu mảng rỗng hoặc chỉ có một phần tử
        if (array == null || array.length <= 1) {
            return;
        }
         // Partition và lấy vị trí chia
        int indexPivot = quickSort(array, left, right);
        // Sắp xếp nửa bên trái
        if (left < indexPivot - 1) {
            sort(array, left, indexPivot - 1);
        }
        // Sắp xếp nửa bên phải
        if (indexPivot < right) {
            sort(array, indexPivot, right);
        }
    }

/**
 *  Bước 1: Yêu cầu người dùng cung cấp kích thước mảng n
 *  Bước 2: Tự động khởi tạo và sinh giá trị ngẫu nhiên cho các ô nhớ mảng
 *  Bước 3: In mang chua sap xep
 *  Buoc 4: su dung thuat toan quick sort de sap xep mang
 *  Buoc 5: In mang da sap xep
 * @param args 
 */
        public static void main(String[] args) {
            // Nhập số lượng phần tử
            int n = MyUtils.inputInteger("Enter number of array: ", true);
            // Sinh mảng ngẫu nhiên
            int[] array = MyUtils.generateRandom(n);
             // Hiển thị mảng trước khi sắp xếp
            System.out.print("Unsorted array: ");
            MyUtils.displayArray(array);
             // Thực hiện Quick Sort
            QuickSort.sort(array, 0, array.length - 1);
             // Hiển thị kết quả
            System.out.print("Sorted array: ");
            MyUtils.displayArray(array);
        }

    }


