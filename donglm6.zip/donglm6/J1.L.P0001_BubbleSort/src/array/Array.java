/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package array;

import java.util.Random;

public class Array {

    private int array[] = null;

    /**
     * This construct a random array.
     *
     * @param number -length of array
     */
    public Array(int number) {
        Random rand = new Random();
        array = new int[number];
        // Loop to initialize each element of the array with a random number
        for (int i = 0; i < number; i++) {
            array[i] = rand.nextInt(number); // Assign a random number to each array element
        }
    }

    /**
     * This method is used to display Arrays on the screen.
     */
    public void printArray() {
        System.out.print(" [");
        // Loop through each element of the array
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i]); // Print the current element
            // Check if it's not the last element
            if (i < array.length - 1) {
                System.out.print(", "); // Print a comma after each element except the last
            } else {
                System.out.print("]"); // Close the bracket after the last element
            }
        }
        System.out.println(); // Print a newline at the end
    }

    /**
     * This method is used to sort array by bubble sort
     *
     */
    public void bubbleSort() {
        int temp;
        boolean swapped;

        // Outer loop: Control passes.
        for (int i = 0; i < array.length - 1; i++) {
            swapped = false;

            // Inner loop: Compare and swap adjacent elements in the unsorted portion.
            for (int j = 0; j < array.length - 1 - i; j++) {
                if (array[j] > array[j + 1]) {
                    temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                    swapped = true;
                }
            }

            // Optimization: If no elements were swapped in a pass, the array is sorted. Stop early.
            if (!swapped) {
                break;
            }
        }
    }
}
