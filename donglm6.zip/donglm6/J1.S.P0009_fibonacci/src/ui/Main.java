/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ui;

import entity.Fibonacci;

/**
 * Lớp Main dùng để chạy chương trình và hiển thị dãy Fibonacci.
 *
 * Chương trình in ra 45 số Fibonacci đầu tiên từ F(0) đến F(44) bằng cách sử
 * dụng phương pháp đệ quy.
 *
 * @author win
 */
public class Main {

    /**
     * Hàm chính của chương trình.
     *
     * @param args đối số dòng lệnh
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // Hiển thị tiêu đề
        System.out.println("The 45 sequence fibonacci:");
        // Khởi tạo đối tượng Fibonacci để tính dãy số
        Fibonacci fibonacci = new Fibonacci(45);
        // In 45 số Fibonacci từ F(0) đến F(44)
        for (int i = 0; i < 45; i++) {
            System.out.print(fibonacci.getFibonacci(i));
            // Kiểm tra phần tử cuối cùng để định dạng đầu ra
            if (i == 44) {
                System.out.println(".");
            } else {
                System.out.print(", ");
            }
        }
        //test
        // Kiểm tra các trường hợp cơ sở
        System.out.println("\nPosition of each element:");
        for (int i = 0; i < 45; i++) {
            System.out.println("Index " + i + ": " + fibonacci.getFibonacci(i));
        }

        System.out.print("[");

        for (int i = 0; i < 45; i++) {
            System.out.print("F(" + i + ")=" + fibonacci.getFibonacci(i));

            if (i < 44) {
                System.out.print(", ");
            }
        }

        System.out.println("]");
        System.out.println("F(0) = " + fibonacci.getFibonacci(0));
        System.out.println("F(1) = " + fibonacci.getFibonacci(1));
        // Kiểm tra giá trị Fibonacci cuối cùng

        System.out.println("F(44) = " + fibonacci.getFibonacci(44));

    }

}
