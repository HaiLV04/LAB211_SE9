/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 * Lớp Fibonacci dùng để tính các số Fibonacci bằng phương pháp đệ quy.
 *
 * Các giá trị Fibonacci đã tính sẽ được lưu vào mảng để tránh tính toán lặp lại
 * nhiều lần (Memoization).
 *
 * @author win
 */
public class Fibonacci {

    /**
     * Mảng lưu các số Fibonacci đã được tính. fibonacci[i] lưu giá trị F(i).
     */
    private int[] fibonacci;

    /**
     * Khởi tạo mảng lưu các số Fibonacci.
     *
     * @param numberOfFibo số lượng phần tử Fibonacci cần lưu
     */
    public Fibonacci(int numberOfFibo) {
        fibonacci = new int[numberOfFibo];
    }

    /**
     * Tính số Fibonacci tại vị trí index bằng đệ quy.
     *
     * Công thức: - F(0) = 0 - F(1) = 1 - F(n) = F(n - 1) + F(n - 2)
     *
     * Sử dụng Memoization để lưu lại các kết quả đã tính, giúp giảm số lần gọi
     * đệ quy không cần thiết.
     *
     * @param index vị trí cần tính trong dãy Fibonacci
     * @return giá trị Fibonacci tại vị trí index
     */
    public int getFibonacci(int index) {
         // Trường hợp cơ sở: F(0) = 0, F(1) = 1
        if (index == 0 || index == 1) {
            return index;
        }
        //Kiểm tra xem F[n] đã được tính hay chưa? F[n]==0 thì là chưa được tính, != là đã tính
        if (fibonacci[index] != 0) {
            return fibonacci[index];
        }
        //Nếu F[n] chưa được tính thì đi tính nó và lưu lại
        fibonacci[index] = getFibonacci(index - 1) + getFibonacci(index - 2);
        return fibonacci[index];
    }
}
