package entity;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Lớp Task đại diện cho một đối tượng công việc trong hệ thống.
 * Chứa các thông tin cơ bản của một công việc và các phương thức truy xuất/cập nhật dữ liệu.
 */
public class Task {
    private int id;
    private int taskTypeID;
    private String requirementName;
    private Date date;
    private double planFrom;
    private double planTo;
    private String assign;
    private String reviewer;
    /**
     * Khởi tạo một đối tượng Task với đầy đủ thông tin truyền vào.
     * * @param id ID của công việc
     * @param taskTypeID ID loại công việc
     * @param requirementName Tên yêu cầu
     * @param date Ngày thực hiện
     * @param planFrom Thời gian bắt đầu
     * @param planTo Thời gian kết thúc
     * @param assign Người được giao
     * @param reviewer Người kiểm duyệt
     */
    public Task(int id, int taskTypeID, String requirementName, Date date, 
            double planFrom, double planTo, String assign,
            String reviewer) {
        this.id = id;
        this.taskTypeID = taskTypeID;
        this.requirementName = requirementName;
        this.date = date;
        this.planFrom = planFrom;
        this.planTo = planTo;
        this.assign = assign;
        this.reviewer = reviewer;
    }
    
    public Task() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getTaskTypeID() {
        return taskTypeID;
    }

    public void setTaskTypeID(int taskTypeID) {
        this.taskTypeID = taskTypeID;
    }

    public String getRequirementName() {
        return requirementName;
    }

    public void setRequirementName(String requirementName) {
        this.requirementName = requirementName;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public double getPlanFrom() {
        return planFrom;
    }

    public void setPlanFrom(double planFrom) {
        this.planFrom = planFrom;
    }

    public double getPlanTo() {
        return planTo;
    }

    public void setPlanTo(double planTo) {
        this.planTo = planTo;
    }

    public String getAssign() {
        return assign;
    }

    public void setAssign(String assign) {
        this.assign = assign;
    }

    public String getReviewer() {
        return reviewer;
    }

    public void setReviewer(String reviewer) {
        this.reviewer = reviewer;
    }
    /**
     * Ghi đè phương thức toString để trả về chuỗi thông tin của Task đã được định dạng.
     * Phương thức này được dùng để in dữ liệu ra màn hình (Console) theo dạng bảng.
     * * @return Chuỗi định dạng chứa đầy đủ thông tin của Task.
     */
    @Override
    public String toString() { 
        // Khởi tạo SimpleDateFormat để định dạng đối tượng Date về dạng chuỗi "dd-MM-yyyy"
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        // Trả về chuỗi được format:
        // Cấu trúc %-15s: Căn lề trái (dấu trừ), cấp khoảng trống 15 ký tự cho chuỗi (s).
        // Cấu trúc %-15.1f: Căn lề trái, cấp 15 khoảng trống, lấy 1 chữ số phần thập phân cho số thực (f).
        return String.format("%-5d%-15s%-15s%-15s%-15.1f%-15s%-15s\n", getId(),getRequirementName(),
                TaskType.getTaskTypeByID(taskTypeID).getName(),
                dateFormat.format(date),getPlanTo()-getPlanFrom(),getAssign(),getReviewer());
    }
    
}
