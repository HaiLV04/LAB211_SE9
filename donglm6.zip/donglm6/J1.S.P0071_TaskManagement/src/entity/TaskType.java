
package entity;

/**
 * Enum TaskType định nghĩa các loại công việc cố định trong hệ thống. Việc sử
 * dụng Enum giúp giới hạn tập giá trị hợp lệ, kiểm soát dữ liệu chặt chẽ hơn và
 * tránh việc người dùng gán sai loại công việc.
 */
public enum TaskType {
    CODE(1, "Code"),
    TEST(2, "Test"),
    DESIGN(3, "Design"),
    REVIEW(4, "Review");
    private int id;
    private String name;

    private TaskType(int id, String name) {
        this.id = id;
        this.name = name;
    }

    /**
     * Phương thức static giúp lấy ra đối tượng TaskType dựa vào ID đầu vào.
     * Phương thức này rất hữu ích để ánh xạ dữ liệu người dùng nhập (số từ 1
     * đến 4) thành đối tượng Enum tương ứng trước khi lưu vào object Task.
     *
     * * @param ID số nguyên (từ 1 đến 4) đại diện cho loại công việc
     * @return Đối tượng TaskType tương ứng (CODE, TEST, DESIGN, hoặc REVIEW)
     * @throws AssertionError nếu truyền vào một ID không hợp lệ (không thuộc
     * 1-4)
     */
    public static TaskType getTaskTypeByID(int ID) {
        switch (ID) {
            case 1:
                return CODE;
            case 2:
                return TEST;
            case 3:
                return DESIGN;
            case 4:
                return REVIEW;
            default:
                throw new AssertionError();
        }
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

}
