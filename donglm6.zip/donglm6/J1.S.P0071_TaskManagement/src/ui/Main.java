package ui;

import controller.Controller;
import entity.Task;
import utils.Validator;

public class Main {

    /**
     * Phương thức main: Khởi chạy ứng dụng Java Console.
     * * @param args các đối số dòng lệnh (không sử dụng).
     */
    public static void main(String[] args) {
        // Khởi tạo đối tượng Controller để làm cầu nối điều khiển các nghiệp vụ
        Controller control = new Controller();
        // Vòng lặp while(true) giữ cho chương trình luôn chạy cho đến khi người dùng chọn thoát (Exit)
        while (true) {
            // Hiển thị Menu và lấy lựa chọn của người dùng thông qua Validator để đảm bảo dữ liệu nhập là số (1-4)
            int choice = Validator.getInt("========= Task program =========\n"
                    + "1.	Add Task\n"
                    + "2.	Delete task\n"
                    + "3.	Display Task\n"
                    + "4.	exit\n"
                    + "Enter your choice: ", "Just 1-> 4", "Invalid!", 1, 4);
            // Xử lý logic theo lựa chọn của người dùng
            switch (choice) {
                case 1:
                    System.out.println("------------Add Task------------");
                    try {
                        // Gọi Controller thực hiện chức năng Add, nhận về ID của task mới
                        int IDTask = control.add();
                        System.out.println("Add success task id: " + IDTask);
                    } catch (Exception e) {
                        // Nếu có lỗi (nhập sai, trùng dữ liệu...), in ra thông điệp lỗi từ Exception
                        System.out.println(e.getMessage());
                    }
                    break;
                case 2:
                    System.out.println("------------Del Task------------");
                    try {
                        // Gọi Controller thực hiện chức năng Delete, nhận về đối tượng Task đã xóa
                        Task task= control.delete();
                        System.out.println("Delete success:");
                        System.out.println(task);
                    } catch (Exception e) {
                        // In lỗi nếu ID không tồn tại
                        System.out.println(e.getMessage());
                    }
                    break;
                case 3:
                    System.out.println("------------Show Task------------");
                    try {
                        // Gọi Controller thực hiện hiển thị danh sách
                        control.show();
                    } catch (Exception e) {
                        // In lỗi nếu danh sách trống
                        System.out.println(e.getMessage());
                    }
                    break;
                case 4:
                    System.exit(0);
            }
        }
    }

}
