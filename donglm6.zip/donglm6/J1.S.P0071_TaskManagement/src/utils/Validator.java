/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author win
 */
/**
 * Lớp Validator (Tiện ích kiểm tra dữ liệu).
 * Chứa các phương thức static dùng để nhập và kiểm tra tính hợp lệ của dữ liệu từ bàn phím.
 * Sử dụng vòng lặp do-while để ép người dùng nhập lại cho đến khi dữ liệu đúng định dạng.
 */
public class Validator {
    private static final Scanner SCANNER = new Scanner(System.in);
    private Validator(){
        
    }
    /**
     * Hàm yêu cầu nhập vào một số nguyên (int) nằm trong khoảng cho trước.
     * * @param messageInfo Lời nhắc hiển thị yêu cầu nhập (VD: "Nhập số: ")
     * @param messsageErrorOutOfRange Lỗi hiển thị khi số nhập vào nằm ngoài [min, max]
     * @param messageErrorNumber Lỗi hiển thị khi nhập chữ hoặc ký tự không phải số nguyên
     * @param min Giá trị tối thiểu cho phép
     * @param max Giá trị tối đa cho phép
     * @return Số nguyên hợp lệ do người dùng nhập
     */
    public static int getInt(String messageInfo,String messsageErrorOutOfRange,
            String messageErrorNumber,int min,int max){
        do {            
            try {
                System.out.print(messageInfo);
                int number = Integer.parseInt(SCANNER.nextLine());
                if(number>=min&&number<=max){
                    return number;
                }else{
                    System.out.println(messsageErrorOutOfRange);
                }
            } catch (NumberFormatException e) {
                System.out.println(messageErrorNumber);
            }
        } while (true);
    }
    /**
     * Hàm yêu cầu nhập vào một số thực (double) nằm trong khoảng cho trước.
     * Hoạt động tương tự như hàm getInt.
     * * @param messageInfo Lời nhắc hiển thị yêu cầu nhập
     * @param messsageErrorOutOfRange Lỗi khi giá trị ngoài khoảng [min, max]
     * @param messageErrorNumber Lỗi khi nhập sai định dạng số (VD: chứa chữ cái)
     * @param min Giá trị tối thiểu
     * @param max Giá trị tối đa
     * @return Số thực hợp lệ
     */
    public static double getDouble(String messageInfo,String messsageErrorOutOfRange,
            String messageErrorNumber,double min,double max){
        do {            
            try {
                System.out.print(messageInfo);
                double number = Double.parseDouble(SCANNER.nextLine());
                if(number>=min&&number<=max){
                    return number;
                }else{
                    System.out.println(messsageErrorOutOfRange);
                }
            } catch (NumberFormatException e) {
                System.out.println(messageErrorNumber);
            }
        } while (true);
    }
    /**
     * Hàm yêu cầu nhập vào một chuỗi (String) thỏa mãn biểu thức chính quy (Regex).
     * * @param messageInfo Lời nhắc hiển thị yêu cầu nhập
     * @param messageError Lỗi hiển thị khi chuỗi không khớp với Regex
     * @param REGEX Biểu thức chính quy dùng để kiểm tra (VD: "[A-Za-z0-9\\s]+" cấm ký tự đặc biệt)
     * @return Chuỗi hợp lệ
     */
    public static String getString(String messageInfo, String messageError, final String REGEX){
        do {            
            System.out.print(messageInfo);
            String str = SCANNER.nextLine();
            if(str.matches(REGEX)){
                return str;
            }
            System.out.println(messageError);
        } while (true);
    }
    /**
     * Hàm yêu cầu nhập vào một ngày tháng (Date) theo đúng định dạng.
     * * @param messageInfo Lời nhắc hiển thị yêu cầu nhập
     * @param messageErrorDate Lỗi khi nhập sai định dạng ngày hoặc ngày không tồn tại
     * @param REGEX Định dạng chuỗi ngày (VD: "dd-MM-yyyy")
     * @return Đối tượng Date hợp lệ
     */
    public static Date getDate(String messageInfo,String messageErrorDate,final String REGEX){
        SimpleDateFormat dateFormat = new SimpleDateFormat(REGEX);
        dateFormat.setLenient(false);
        do {            
            System.out.print(messageInfo);
            try {
                Date date = dateFormat.parse(SCANNER.nextLine());
                return date;
            } catch (ParseException e) {
                System.out.println(messageErrorDate);
            }
        } while (true);
    }
    
}
