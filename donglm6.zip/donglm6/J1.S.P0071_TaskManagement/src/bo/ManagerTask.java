
package bo;

import entity.Task;
import java.util.ArrayList;
import java.util.Date;

/**
 * Lớp ManagerTask đóng vai trò Business Object (BO). Chịu trách nhiệm quản lý
 * danh sách các Task, thực hiện các logic nghiệp vụ như thêm, xóa, kiểm tra
 * trùng lặp và định dạng dữ liệu hiển thị.
 */
public class ManagerTask {
    // Danh sách lưu trữ các đối tượng Task
    private ArrayList<Task> list;
    // Biến lưu ID của Task cuối cùng để phục vụ cơ chế ID tự tăng
    private int lastID;
    /**
     * Khởi tạo đối tượng ManagerTask. Khởi tạo danh sách rỗng và đặt ID bắt đầu
     * là 0.
     */
    public ManagerTask() {
        list = new ArrayList<>();
        lastID = 0;
    }
// Các phương thức Getter/Setter cho thuộc tính list và lastID
    public ArrayList<Task> getList() {
        return list;
    }

    public void setList(ArrayList<Task> list) {
        this.list = list;
    }

    public int getLastID() {
        return lastID;
    }

    public void setLastID(int lastID) {
        this.lastID = lastID;
    }
    /**
     * Kiểm tra xem một Task có bị trùng lặp với bất kỳ Task nào đã có trong
     * danh sách không. So sánh dựa trên tất cả các thuộc tính quan trọng của
     * Task.
     *
     * * @return true nếu tìm thấy Task giống hệt, false nếu không.
     */
    private boolean isDuplicate(int taskTypeID, String requirementName, Date date,
            double planFrom, double planTo, String assign,
            String reviewer) {
        for (Task task : list) {
            // So sánh từng thuộc tính: ID loại, Tên yêu cầu, Ngày, Thời gian, Người làm, Người duyệt
            if (task.getTaskTypeID() == taskTypeID
                    && task.getRequirementName().equalsIgnoreCase(requirementName)
                    && task.getDate().compareTo(date) == 0
                    && task.getPlanFrom() == planFrom
                    && task.getPlanTo() == planTo
                    && task.getAssign().equalsIgnoreCase(assign)
                    && task.getReviewer().equalsIgnoreCase(reviewer)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Thêm một Task mới vào danh sách. Tự động sinh ID mới bằng cách tăng
     * lastID.
     *
     * * @return ID của Task vừa được thêm.
     * @throws Exception nếu Task đã tồn tại hoặc không thêm được vào List.
     */
    public int add(int taskTypeID, String requirementName, Date date,
            double planFrom, double planTo, String assign,
            String reviewer) throws Exception {
        // Bước 1: Kiểm tra trùng lặp
        if (isDuplicate(taskTypeID, requirementName, date, planFrom, planTo, assign, reviewer)) {
            throw new Exception("This task is existed!");
        }
        // Bước 2: Tạo Task mới với ID tự tăng (pre-increment: ++lastID)
        Task newTask = new Task(++lastID, taskTypeID, requirementName, date, planFrom, planTo, assign, reviewer);
        // Bước 3: Thêm vào ArrayList
        if (list.add(newTask)) {
            return newTask.getId();
        }
        throw new Exception("Can not add!");
    }

    /**
     * Tìm kiếm chỉ số (index) của Task trong ArrayList dựa trên ID.
     *
     * * @param id ID cần tìm.
     * @return index của phần tử trong list, hoặc -1 nếu không tìm thấy.
     */
    private int getIndexByID(int id) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getId() == id) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Xóa một Task dựa trên ID.
     *
     * * @param id ID của Task cần xóa.
     * @return Đối tượng Task đã bị xóa (để hiển thị thông tin).
     * @throws Exception nếu không tìm thấy ID.
     */
    public Task deleteTaskByID(int id) throws Exception {
        int index = getIndexByID(id);
        if (index == -1) {
            throw new Exception("Task ID does not exist!");
        }
        return list.remove(index);
    }

    /**
     * Trả về chuỗi định dạng (String format) của toàn bộ danh sách Task. Dùng
     * để hiển thị trong bảng.
     *
     * * @return Chuỗi danh sách hoặc null nếu danh sách rỗng.
     */
    @Override
    public String toString() {
        if (list.isEmpty()) {
            return null;
        }
        // Tạo dòng tiêu đề cho bảng
        String str = String.format("%-5s%-15s%-15s%-15s%-15s%-15s%-15s\n", "ID", "Name", "Task Type", "Date",
                "Time", "Assignee", "Reviewer");
        // Duyệt danh sách và cộng dồn thông tin của từng task
        for (Task task : list) {
            str += task.toString();
        }
        return str;
    }

}
