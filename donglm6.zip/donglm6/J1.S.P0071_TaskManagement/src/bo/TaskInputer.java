package bo;

import entity.Task;
import utils.Validator;

/**
 * Lớp TaskInputer chịu trách nhiệm tương tác với người dùng để nhập thông tin
 * cho một công việc (Task). Đóng vai trò tập hợp các dữ liệu hợp lệ thông qua
 * lớp Validator trước khi gửi về Controller xử lý.
 */
public class TaskInputer {
// Đối tượng Task tạm thời dùng để chứa thông tin người dùng đang nhập

    private Task task;

    /**
     * Constructor khởi tạo đối tượng TaskInputer. Cấp phát bộ nhớ cho một đối
     * tượng Task rỗng để sẵn sàng hứng dữ liệu.
     */
    public TaskInputer() {
        task = new Task();
    }

    /**
     * Phương thức thực hiện việc yêu cầu người dùng nhập từng trường thông tin
     * của Task. Áp dụng các quy tắc kiểm tra (validation) chặt chẽ cho từng
     * trường.
     *
     * * @return Đối tượng Task chứa đầy đủ thông tin hợp lệ (chưa có ID tự
     * sinh).
     */
    public Task input() {
        // 1. Nhập Tên Requirement: Chỉ cho phép chữ cái, số và khoảng trắng (Regex: [A-Za-z0-9\\s]+)
        task.setRequirementName(Validator.getString("Requirement Name: ",
                "Invalid!", "[A-Za-z0-9\\s]+"));
        // 2. Nhập Loại công việc: Giới hạn lựa chọn từ 1 đến 4
        task.setTaskTypeID(Validator.getInt("1. Code\n"
                + "2. Test\n"
                + "3. Design\n"
                + "4. Review\n"
                + "Enter your choice: ", "Just be 1 -> 4",
                "Invalid!", 1, 4));
        // 3. Nhập Ngày: Ép buộc theo định dạng dd-MM-yyyy
        task.setDate(Validator.getDate("Enter Date: ",
                "Invalid! Please enter format: dd-MM-yyyy", "dd-MM-yyyy"));
        while (true) {
            // 4. Nhập Thời gian bắt đầu (Plan From)
            // Lấy số thực trong khoảng từ 8.0 đến 17.0
            task.setPlanFrom(Validator.getDouble("From: ", "Just be 8 -> 17",
                    "Invalid!", 8, 17));
            // Chuyển số double thành chuỗi để kiểm tra phần thập phân
            String from = task.getPlanFrom() + "";
            // Cắt chuỗi theo dấu "." (dùng \\. vì trong regex dấu . là ký tự đặc biệt)
            // Kiểm tra phần tử thứ 1 (phần thập phân) xem có phải là "0" hoặc "5" không
            if (from.split("\\.")[1].equals("0") || from.split("\\.")[1].equals("5")) {
                break;
            } else {
                System.out.println("Must be x.0 or x.5");
            }
        }
        // 5. Nhập Thời gian kết thúc (Plan To)
        while (true) {
            // Giá trị Min của Plan To luôn phải lớn hơn Plan From ít nhất 0.5 giờ (logic logic thời gian)
            // Giá trị Max là 17.5
            task.setPlanTo(Validator.getDouble("To: ",
                    "Just be " + (task.getPlanFrom() + 0.5) + "-> 17.5",
                    "Invalid!", (task.getPlanFrom() + 0.5), 17.5));
            // Tương tự, kiểm tra phần thập phân phải là .0 hoặc .5
            String to = task.getPlanTo() + "";
            if (to.split("\\.")[1].equals("0") || to.split("\\.")[1].equals("5")) {
                break;
            } else {
                System.out.println("Must be x.0 or x.5");
            }
        }
        // 6. Nhập Người được giao: Chặn ký tự đặc biệt
        task.setAssign(Validator.getString("Assignee: ",
                "Invalid!", "[A-Za-z0-9\\s]+"));
        // 7. Nhập Người kiểm duyệt: Chặn ký tự đặc biệt
        task.setReviewer(Validator.getString("Reviewer: ",
                "Invalid!", "[A-Za-z0-9\\s]+"));
        // Trả về đối tượng Task đã mang đầy đủ thông tin hợp lệ
        return task;
    }
}
