package controller;

import bo.ManagerTask;
import bo.TaskInputer;
import entity.Task;
import utils.Validator;

/**
 * Lớp Controller điều phối luồng hoạt động của chương trình quản lý công việc
 *
 * @author win
 */
public class Controller {
// Đối tượng quản lý danh sách và logic nghiệp vụ của Task

    private ManagerTask managerTask;
    // Đối tượng phụ trách việc nhập thông tin Task từ bàn phím
    private TaskInputer inputer;

    /**
     * Khởi tạo đối tượng Controller. Cấp phát bộ nhớ cho managerTask ngay khi
     * Controller được tạo ra để sẵn sàng quản lý danh sách công việc.
     */
    public Controller() {
        managerTask = new ManagerTask();
    }

    public ManagerTask getManagerTask() {
        return managerTask;
    }

    public void setManagerTask(ManagerTask managerTask) {
        this.managerTask = managerTask;
    }

    /**
     * Chức năng Thêm mới một công việc (Add Task).
     *
     * * @return ID của Task vừa được thêm thành công.
     * @throws Exception nếu có lỗi xảy ra (ví dụ: Task bị trùng lặp dữ liệu).
     */
    public int add() throws Exception {
        inputer = new TaskInputer();
        // Gọi hàm input() để người dùng nhập toàn bộ thông tin hợp lệ. 
        // Trả về một đối tượng Task tạm thời chứa thông tin vừa nhập.
        Task task = inputer.input();
        // Truyền các thuộc tính của task tạm thời xuống ManagerTask để kiểm tra logic (trùng lặp) 
        // và lưu vào danh sách chính thức. Hàm add() của ManagerTask sẽ trả về ID tự sinh.
        return managerTask.add(task.getTaskTypeID(), task.getRequirementName(),
                task.getDate(), task.getPlanFrom(), task.getPlanTo(),
                task.getAssign(), task.getReviewer());
    }

    /**
     * Chức năng Xóa một công việc (Delete Task).
     *
     * * @return Đối tượng Task vừa bị xóa khỏi danh sách (để hiển thị ra màn
     * hình).
     * @throws Exception nếu không tìm thấy ID trong danh sách hoặc danh sách
     * trống.
     */
    public Task delete() throws Exception {
        // Sử dụng Validator để ép người dùng nhập một số nguyên (ID của Task cần xóa).
        // Cho phép nhập từ giá trị nhỏ nhất đến lớn nhất của kiểu Integer.
        int ID = Validator.getInt("Task ID: ", "Error range!", "Invalid!",
                Integer.MIN_VALUE, Integer.MAX_VALUE);
        // Gọi ManagerTask để tiến hành tìm và xóa Task theo ID.
        return managerTask.deleteTaskByID(ID);
    }

    /**
     * Chức năng Hiển thị danh sách công việc (Show Task).
     *
     * * @throws Exception nếu danh sách hiện tại đang trống rỗng.
     */
    public void show() throws Exception {
        // Gọi hàm toString() của ManagerTask để lấy toàn bộ chuỗi dữ liệu đã được định dạng (format).
        String str = managerTask.toString();
        if (str == null) {
            // Nếu chuỗi trả về là null (đồng nghĩa với ArrayList đang rỗng), ném ra ngoại lệ.
            throw new Exception("This list is empty!");
        }
        // In chuỗi danh sách công việc ra màn hình Console.
        System.out.println(str);
    }
}
