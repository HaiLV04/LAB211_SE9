/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

/**
 * @author Tuandz
 */
/**
 * Lớp hỗ trợ kiểm tra dữ liệu đầu vào.
 *
 * Cung cấp các phương thức nhập và kiểm tra: - Số nguyên. - Số thực. - Chuỗi
 * theo biểu thức chính quy. - Ngày tháng theo định dạng xác định.
 */
public class Validator {

    private static final Scanner SCANNER = new Scanner(System.in);

    private Validator() {
    }

    /**
     * Nhập và kiểm tra số nguyên trong khoảng cho phép.
     *
     * @param messageInfo thông báo nhập dữ liệu
     * @param messageErrorOutOfRange thông báo khi ngoài phạm vi
     * @param messageErrorInvalidNumber thông báo khi nhập sai định dạng
     * @param min giá trị nhỏ nhất
     * @param max giá trị lớn nhất
     * @return số nguyên hợp lệ
     */
    public static int getInt(
            String messageInfo,
            String messageErrorOutOfRange,
            String messageErrorInvalidNumber,
            int min, int max) {
        do {
            try {
                System.out.print(messageInfo);
                int number = Integer.parseInt(SCANNER.nextLine());
                if (number >= min && number <= max) {
                    return number;
                }
                System.out.println(messageErrorOutOfRange);
            } catch (NumberFormatException e) {
                System.out.println(messageErrorInvalidNumber);
            }
        } while (true);
    }

    /**
     * Nhập và kiểm tra số thực trong khoảng cho phép.
     *
     * @param messageInfo thông báo nhập dữ liệu
     * @param messageErrorOutOfRange thông báo khi ngoài phạm vi
     * @param messageErrorInvalidNumber thông báo khi nhập sai định dạng
     * @param min giá trị nhỏ nhất
     * @param max giá trị lớn nhất
     * @return số thực hợp lệ
     */
    public static double getDouble(
            String messageInfo,
            String messageErrorOutOfRange,
            String messageErrorInvalidNumber,
            double min, double max) {
        do {
            try {
                System.out.println(messageInfo);
                double number = Double.parseDouble(SCANNER.nextLine());
                if (number >= min && number <= max) {
                    return number;
                }
                System.out.println(messageErrorOutOfRange);
            } catch (NumberFormatException e) {
                System.out.println(messageErrorInvalidNumber);
            }
        } while (true);
    }

    /**
     * Nhập và kiểm tra chuỗi theo biểu thức chính quy.
     *
     * @param messageInfo thông báo nhập dữ liệu
     * @param messageError thông báo lỗi
     * @param REGEX biểu thức chính quy
     * @return chuỗi hợp lệ
     */
    public static String getString(String messageInfo, String messageError,
            final String REGEX) {
        do {
            System.out.print(messageInfo);
            String str = SCANNER.nextLine();
            if (str.matches(REGEX)) {
                return str;
            }
            System.out.println(messageError);
        } while (true);
    }

    /**
     * Nhập và kiểm tra ngày hợp lệ trong khoảng cho phép.
     *
     * @param messageInfo thông báo nhập dữ liệu
     * @param messageErrorOutOfRange thông báo khi ngoài phạm vi
     * @param messageErrorInvalidDate thông báo khi sai định dạng ngày
     * @param REGEX định dạng ngày
     * @param min ngày nhỏ nhất
     * @param max ngày lớn nhất
     * @return ngày hợp lệ
     */
    public static Date getDate(
            String messageInfo,
            String messageErrorOutOfRange,
            String messageErrorInvalidDate,
            final String REGEX,
            Date min, Date max) {
        //set format of date
        SimpleDateFormat dateFormat = new SimpleDateFormat(REGEX);
        dateFormat.setLenient(false);
        //force user input exectly a date
        while (true) {
            System.out.print(messageInfo);
            try {
                // Chuyển chuỗi nhập thành đối tượng Date
                Date date = dateFormat.parse(SCANNER.nextLine());
                // Kiểm tra ngày nằm trong khoảng cho phép
                if (date.compareTo(min) >= 0 && date.compareTo(max) <= 0) {
                    return date;
                }
                System.err.println(messageErrorOutOfRange);
            } catch (ParseException e) {
                // Người dùng nhập sai định dạng ngày
                System.err.println(messageErrorInvalidDate);
            }
        }
    }
}
