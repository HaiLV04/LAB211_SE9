/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import java.util.Date;

/**
 * Lớp lưu thông tin lịch sử thay đổi lương của công nhân.
 *
 * Mỗi bản ghi lịch sử gồm: - Công nhân được cập nhật lương. - Mức lương sau khi
 * cập nhật. - Trạng thái thay đổi (UP hoặc DOWN). - Thời gian thực hiện thay
 * đổi.
 *
 * @author win
 */
public class SalaryHistory implements Comparable<SalaryHistory>, Serializable {

    /**
     * Công nhân được thay đổi lương. Mức lương sau khi cập nhật. Trạng thái
     * thay đổi lương (UP/DOWN). Ngày thực hiện thay đổi lương.
     */
    private Worker worker;
    private double salaryUpdate;
    private SalaryStatus status;
    private Date date;

    /**
     * Khởi tạo một bản ghi lịch sử lương.
     *
     * @param worker công nhân được cập nhật
     * @param salaryUpdate mức lương sau khi cập nhật
     * @param status trạng thái UP hoặc DOWN
     * @param date ngày thực hiện
     * @throws Exception nếu dữ liệu không hợp lệ
     */
    public SalaryHistory(Worker worker, double salaryUpdate, SalaryStatus status, Date date) throws Exception {
        setWorker(worker);
        setSalaryUpdate(salaryUpdate);
        setStatus(status);
        setDate(date);
    }

    public Worker getWorker() {
        return worker;
    }

    /**
     * Thiết lập công nhân cho bản ghi lịch sử.
     *
     * @param worker công nhân cần lưu
     * @throws Exception nếu worker bằng null
     */
    public void setWorker(Worker worker) throws Exception {
        if (worker != null) {
            this.worker = worker;
        } else {
            throw new Exception("Worker can not null!");
        }
    }

    public SalaryStatus getStatus() {
        return status;
    }

    /**
     * Thiết lập trạng thái thay đổi lương.
     *
     * @param status trạng thái UP hoặc DOWN
     * @throws Exception nếu status bằng null
     */
    public void setStatus(SalaryStatus status) throws Exception {
        if (status != null) {
            this.status = status;
        } else {
            throw new Exception("Status can not null!");
        }
    }

    public Date getDate() {
        return date;
    }

    /**
     * Thiết lập ngày thay đổi lương.
     *
     * @param date ngày thực hiện
     * @throws Exception nếu date bằng null
     */
    public void setDate(Date date) throws Exception {
        if (date != null) {
            this.date = date;
        } else {
            throw new Exception("Date can not null!");
        }
    }

    public double getSalaryUpdate() {
        return salaryUpdate;
    }

    /**
     * Thiết lập mức lương sau khi cập nhật.
     *
     * @param salaryUpdate mức lương mới
     * @throws Exception nếu lương nhỏ hơn 0
     */
    public void setSalaryUpdate(double salaryUpdate) throws Exception {
        if (salaryUpdate >= 0) {
            this.salaryUpdate = salaryUpdate;
        } else {
            throw new Exception("salaryUpdate must be >=0");
        }
    }

    /**
     * So sánh hai bản ghi lịch sử theo mã công nhân. Dùng để sắp xếp danh sách
     * lịch sử.
     *
     * @param o bản ghi lịch sử cần so sánh
     * @return giá trị so sánh theo mã công nhân
     */
    @Override
    public String toString() {
        return "SalaryHistory{" + worker.getId() + ", " + salaryUpdate + ", " + status + ", " + date + '}';
    }

    @Override
    public int compareTo(SalaryHistory o) {
        return worker.getId().compareTo(o.worker.getId());
    }

}
