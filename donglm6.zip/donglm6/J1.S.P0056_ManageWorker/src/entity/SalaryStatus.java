/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 * Enum biểu diễn trạng thái thay đổi lương của công nhân.
 *
 * UP : Tăng lương. DOWN : Giảm lương.
 *
 * @author win
 */
public enum SalaryStatus {
    /**
     * Trạng thái tăng lương. Trạng thái giảm lương.
     */
    UP, DOWN;

    /**
     * Trả về trạng thái UP.
     *
     * @return UP
     */
    public static SalaryStatus getUP() {
        return UP;
    }

    /**
     * Trả về trạng thái DOWN.
     *
     * @return DOWN
     */
    public static SalaryStatus getDOWN() {
        return DOWN;
    }
}
