/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ui;

import controller.Controller;
import entity.Worker;
import utils.Validator;

/**
 * Lớp chạy chương trình Worker Management.
 *
 * Hiển thị menu và điều hướng người dùng đến các chức năng: - Add Worker - Up
 * Salary - Down Salary - Display Information Salary - Exit
 *
 * @author win
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Khởi tạo bộ điều khiển chương trình
        Controller control = new Controller();
        do {
            // Hiển thị menu và lấy lựa chọn từ người dùng
            int choice = Validator.getInt("======== Worker Management =========\n"
                    + "1.	Add Worker\n"
                    + "2.	Up salary\n"
                    + "3.	Down salary\n"
                    + "4.	Display Information salary\n"
                    + "5.	Exit\nEnter your choice: ", "Just be 1-> 5", "Invalid!", 1, 5);
            switch (choice) {
                // Thêm công nhân mới
                case 1:
                    try {
                    System.out.println("--------- Add Worker ----------");
                    Worker worker = control.addWorker();
                    System.out.println("Add success: " + worker);
                } catch (Exception ex) {
                    System.out.println(ex.getMessage());
                }
                break;
                // Tăng lương công nhân
                case 2:
                    try {
                    System.out.println("------- Up/Down Salary --------");
                    Worker workerUp = control.upSalary();
                    System.out.println("Up salary success:");
                    System.out.println(workerUp);
                } catch (Exception ex) {
                    System.out.println(ex.getMessage());
                }
                break;
                // Giảm lương công nhân
                case 3:
                    try {
                    System.out.println("------- Up/Down Salary --------");
                    Worker workerDown = control.downSalary();
                    System.out.println("Down salary success:");
                    System.out.println(workerDown);
                } catch (Exception ex) {
                    System.out.println(ex.getMessage());
                }
                break;
                // Hiển thị lịch sử thay đổi lương
                case 4:
                    control.showHistorySalary();
                    break;
                // Thoát chương trình
                case 5:
                    System.exit(0);
                    break;
            }
        } while (true);
    }

}
