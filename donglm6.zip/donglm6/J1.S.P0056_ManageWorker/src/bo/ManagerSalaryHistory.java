/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bo;

import entity.SalaryHistory;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Lớp quản lý danh sách lịch sử thay đổi lương của công nhân.
 *
 * Chức năng: - Thêm lịch sử tăng/giảm lương. - Kiểm tra lịch sử đã tồn tại. -
 * Sắp xếp lịch sử theo mã công nhân. - Hiển thị danh sách lịch sử lương.
 *
 * @author win
 */
public class ManagerSalaryHistory {

    /**
     * Danh sách lưu lịch sử thay đổi lương.
     */
    private List<SalaryHistory> list;

    /**
     * Khởi tạo danh sách lịch sử rỗng.
     */
    public ManagerSalaryHistory() {
        this.list = new ArrayList<>();
    }

    /**
     * Kiểm tra một bản ghi lịch sử đã tồn tại hay chưa.
     *
     * Hai bản ghi được xem là trùng nhau khi: - Cùng mã công nhân. - Cùng trạng
     * thái (UP/DOWN). - Cùng ngày cập nhật. - Cùng mức lương sau cập nhật.
     *
     * @param history bản ghi cần kiểm tra
     * @return true nếu bản ghi đã tồn tại, ngược lại false
     */
    private boolean isExisted(SalaryHistory history) {
        // Duyệt danh sách lịch sử hiện có
        for (SalaryHistory salaryHistory : list) {
            // Kiểm tra bản ghi trùng hoàn toàn
            if (salaryHistory.getWorker().getId().equalsIgnoreCase(history.getWorker().getId())
                    && salaryHistory.getStatus().equals(history.getStatus())
                    && salaryHistory.getDate().equals(history.getDate())
                    && salaryHistory.getSalaryUpdate() == history.getSalaryUpdate()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Thêm một bản ghi lịch sử lương vào danh sách.
     *
     * @param history bản ghi lịch sử cần thêm
     * @return true nếu thêm thành công
     * @throws Exception nếu bản ghi đã tồn tại
     */
    public boolean addSalaryHistory(SalaryHistory history) throws Exception {
        if (isExisted(history)) {
            throw new Exception("This record history is existed!!!");
        }
        return list.add(history);
    }

    /**
     * Sắp xếp danh sách lịch sử theo mã công nhân.
     */
    private void sortByID() {
        Collections.sort(list);
    }

    /**
     * Trả về chuỗi chứa toàn bộ lịch sử thay đổi lương.
     *
     * Danh sách sẽ được sắp xếp theo mã công nhân trước khi hiển thị.
     *
     * @return chuỗi lịch sử lương hoặc null nếu danh sách rỗng
     */
    @Override
    public String toString() {
        if (list.isEmpty()) {
            return null;
        }
        sortByID();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String str = String.format("%7s%10s%10s%10s%10s%15s\n", "Code", "Name", "Age", "Salary", "Status", "Date");
        for (int i = 0; i < list.size(); i++) {
            String formattedDate = dateFormat.format(list.get(i).getDate());
            str += String.format("%7s%10s%10d%10.0f%10s%15s\n", list.get(i).getWorker().getId(),
                    list.get(i).getWorker().getName(), list.get(i).getWorker().getAge(),
                    list.get(i).getSalaryUpdate(), list.get(i).getStatus(), formattedDate);
        }
        return str;
    }
}
