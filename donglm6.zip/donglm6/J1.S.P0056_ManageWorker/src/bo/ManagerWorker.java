/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bo;

import entity.SalaryStatus;
import entity.Worker;
import java.util.ArrayList;
import java.util.List;

/**
 * Lớp quản lý danh sách công nhân.
 *
 * Chức năng: - Thêm công nhân mới. - Kiểm tra công nhân tồn tại. - Tìm công
 * nhân theo mã. - Tăng hoặc giảm lương công nhân.
 *
 * @author win
 */
public class ManagerWorker {

    /**
     * Danh sách công nhân.
     */
    private List<Worker> list;

    /**
     * Trả về bản sao của danh sách công nhân.
     *
     * @return danh sách công nhân
     */
    public List<Worker> getList() {
        return new ArrayList<>(list);
    }

    /**
     * Khởi tạo danh sách công nhân rỗng.
     */
    public ManagerWorker() {
        this.list = new ArrayList<>();
    }

    /**
     * Tìm công nhân theo mã.
     *
     * @param id mã công nhân cần tìm
     * @return đối tượng Worker nếu tìm thấy, ngược lại trả về null
     */
    private Worker getWorker(String id) {
        // Duyệt danh sách để tìm công nhân theo mã
        for (Worker workers : list) {
            // So sánh không phân biệt chữ hoa chữ thường
            if (workers.getId().equalsIgnoreCase(id)) {
                return workers;
            }
        }
        return null;
    }

    /**
     * Kiểm tra mã công nhân đã tồn tại hay chưa.
     *
     * @param id mã công nhân cần kiểm tra
     * @return true nếu tồn tại, ngược lại false
     */
    public boolean isExist(String id) {
    for (Worker workers : list) {
        if (workers.getId().equalsIgnoreCase(id)) {
            return true;
        }
    }
    return false;
}

    /**
     * Thêm công nhân mới vào danh sách.
     *
     * @param worker công nhân cần thêm
     * @return true nếu thêm thành công
     * @throws Exception nếu mã công nhân đã tồn tại
     */
    public boolean add(Worker worker) throws Exception {
        // Kiểm tra mã công nhân đã tồn tại
        if (isExist(worker.getId())) {
            throw new Exception("Worker with ID " + worker.getId() + " already exists.");
        }
        // Thêm công nhân vào danh sách
        return list.add(worker);
    }

    /**
     * Thay đổi lương của công nhân.
     *
     * Nếu trạng thái là UP thì cộng thêm lương. Nếu trạng thái là DOWN thì trừ
     * lương.
     *
     * @param status trạng thái thay đổi lương (UP hoặc DOWN)
     * @param code mã công nhân
     * @param amount số tiền thay đổi
     * @return công nhân sau khi cập nhật lương
     * @throws Exception nếu không tìm thấy công nhân, số tiền không hợp lệ hoặc
     * lương sau khi giảm nhỏ hơn 0
     */
    public Worker changeSalary(SalaryStatus status, String code, double amount) throws Exception {
        // Kiểm tra mã công nhân có tồn tại hay không

        if (!isExist(code)) {
            throw new Exception("Can not found code!");
        }
        // Kiểm tra số tiền thay đổi phải lớn hơn 0
        if (amount <= 0) {
            throw new Exception("Amount of money must be > 0 ");
        }
        // Lấy công nhân cần cập nhật lương
        Worker worker = getWorker(code);
        switch (status) {
            // Tăng lương
            case UP:
                worker.setSalary(worker.getSalary() + amount);
                break;
            // Giảm lương
            case DOWN:
                if (worker.getSalary() - amount < 0) {
                    throw new Exception("Can not down " + amount);
                }
                worker.setSalary(worker.getSalary() - amount);
                break;
        }
        // Trả về công nhân sau khi cập nhật
        return worker;
    }

}
