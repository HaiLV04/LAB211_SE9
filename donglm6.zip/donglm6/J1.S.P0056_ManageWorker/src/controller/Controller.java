/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import bo.ManagerSalaryHistory;
import bo.ManagerWorker;
import entity.SalaryHistory;
import entity.SalaryStatus;
import entity.Worker;
import java.util.Date;
import utils.Validator;

/**
 * Lớp điều khiển chính của chương trình.
 *
 * Chức năng: - Thêm công nhân. - Tăng lương công nhân. - Giảm lương công nhân.
 * - Hiển thị lịch sử thay đổi lương.
 *
 * @author win
 */
public class Controller {

    /**
     * Quản lý lịch sử thay đổi lương.
     */
    private ManagerSalaryHistory salaryHistory;
    /**
     * Quản lý danh sách công nhân.
     */
    private ManagerWorker workers;

    /**
     * Khởi tạo các đối tượng quản lý.
     */
    public Controller() {
        this.salaryHistory = new ManagerSalaryHistory();
        this.workers = new ManagerWorker();
    }

    /**
     * Nhập thông tin và thêm công nhân mới.
     *
     * @return công nhân vừa được thêm
     * @throws Exception nếu thêm thất bại hoặc dữ liệu không hợp lệ
     */
    public Worker addWorker() throws Exception {
        // Nhập mã công nhân và chuyển thành chữ hoa
        String id;
        do {
            id = Validator.getString(
                    "Enter id: ",
                    "Invalid!",
                    "[Ww]\\d+").toUpperCase();

            if (!workers.isExist(id)) {
                break;
            }
            System.out.println("Worker with ID " + id + " already exists. Please input again");
        } while (true);
        // Nhập tên công nhân
        String name = Validator.getString("Enter Name: ", "Invalid!", "[A-Za-z\\s]+");
        // Nhập tuổi từ 18 đến 50
        int age = Validator.getInt("Enter age: ", "age >= 18 and <=50 !", "Invalid!", 18, 50);
        // Nhập lương lớn hơn 0
        double salary = Validator.getDouble("Enter Salary: ", "salary must be > 0", "Invalid!", Double.MIN_VALUE, Double.MAX_VALUE);
        // Nhập nơi làm việc
        String workLocation = Validator.getString("Enter work location: ", "Invalid!", "[A-Za-z0-9\\s]+");
        // Tạo đối tượng công nhân
        Worker worker = new Worker(id, name, age, salary, workLocation);
        // Thêm công nhân vào danh sách
        if (workers.add(worker)) {
            return worker;
        }
        throw new Exception("Add fail");
    }

    /**
     * Tăng lương cho công nhân.
     *
     * @return công nhân sau khi tăng lương
     * @throws Exception nếu danh sách rỗng hoặc dữ liệu không hợp lệ
     */
    public Worker upSalary() throws Exception {
        // Kiểm tra danh sách công nhân
        if (workers.getList().isEmpty()) {
            throw new Exception("List is empty!");
        }
        // Nhập mã công nhân
        String code = Validator.getString("Enter id: ", "Invalid!", "[Ww]\\d+");
        // Nhập số tiền tăng
        double amount = Validator.getDouble("Enter Salary: ", "salary must be > 0", "Invalid!", Double.MIN_VALUE, Double.MAX_VALUE);
        // Cập nhật lương
        Worker worker = workers.changeSalary(SalaryStatus.UP, code, amount);
        // Lưu lịch sử tăng lương
        if (salaryHistory.addSalaryHistory(new SalaryHistory(worker, worker.getSalary(), SalaryStatus.UP, new Date()))) {
            return worker;
        }
        throw new Exception("Can not up salary");
    }

    /**
     * Giảm lương cho công nhân.
     *
     * @return công nhân sau khi giảm lương
     * @throws Exception nếu danh sách rỗng hoặc dữ liệu không hợp lệ
     */
    public Worker downSalary() throws Exception {
        // Kiểm tra danh sách công nhân
        if (workers.getList().isEmpty()) {
            throw new Exception("List is empty!");
        }
        // Nhập mã công nhân
        String code = Validator.getString(
                "Enter id: ",
                "Invalid!",
                "[Ww]\\d+");

// Lấy công nhân hiện tại để lấy lương hiện tại
        Worker currentWorker = null;

        for (Worker w : workers.getList()) {
            if (w.getId().equalsIgnoreCase(code)) {
                currentWorker = w;
                break;
            }
        }

        if (currentWorker == null) {
            throw new Exception("Can not found code!");
        }

// Khai báo worker để dùng bên ngoài vòng lặp
        Worker worker;

        while (true) {

            // Nhập số tiền giảm
            double amount = Validator.getDouble(
                    "Enter Salary: ",
                    "salary must be > 0",
                    "Invalid!",
                    Double.MIN_VALUE,
                    Double.MAX_VALUE);

            try {
                // Cập nhật lương
                worker = workers.changeSalary(
                        SalaryStatus.DOWN,
                        code,
                        amount);
                break;
            } catch (Exception ex) {
                // Nếu số tiền giảm lớn hơn lương hiện tại thì nhập lại
                if (ex.getMessage().startsWith("Can not down")) {
                    System.out.println(
                            "Amount must be smaller than current salary ("
                            + currentWorker.getSalary() + ")!"
                    );
                } else {
                    throw ex;
                }
            }
        }
        // Lưu lịch sử giảm lương
        if (salaryHistory.addSalaryHistory(new SalaryHistory(worker, worker.getSalary(), SalaryStatus.DOWN, new Date()))) {
            return worker;
        }
        throw new Exception("Can not down salary");
    }

    /**
     * Hiển thị lịch sử thay đổi lương.
     */
    public void showHistorySalary() {
        // Lấy chuỗi lịch sử đã được format

        String result = salaryHistory.toString();
        if (result == null) {
            // Kiểm tra lịch sử có dữ liệu hay không
            System.out.println("History Salary is empty");
        } else {
            System.out.println(result);
        }
    }
}
