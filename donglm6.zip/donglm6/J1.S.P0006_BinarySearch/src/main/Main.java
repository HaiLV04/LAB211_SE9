/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import entity.BinarySearch;
import java.util.Arrays;
import utils.Validator;

/**
 *
 * @author win
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // Nhập số lượng phần tử của mảng
        int number = Validator.getInt("Enter number of array: ",
                "Number must be >0", "Invalid!", 1, Integer.MAX_VALUE);
         // Khai báo đối tượng BinarySearch
        BinarySearch array = null;
        try {
             // Khởi tạo mảng ngẫu nhiên
            array = new BinarySearch(number);
        } catch (Exception e) {
             // Hiển thị lỗi nếu có
            System.out.println(e.getMessage());
        }
        // Hiển thị mảng sau khi sắp xếp
        array.display();
         // Nhập giá trị cần tìm kiếm
        int key = Validator.getInt("Enter search value: ",
                "Error range!", "Invalid!", Integer.MIN_VALUE, Integer.MAX_VALUE);
         
        // Tìm vị trí của key trong mảng
        int[] indexes = array.binarySearchAll(key);
        // Kiểm tra kết quả tìm kiếm
        if (indexes.length == 0) {
            System.out.println("Can not found");
        } else {
            System.out.println("Found " + key + " at index: " + Arrays.toString(indexes));
        }
    }

}
