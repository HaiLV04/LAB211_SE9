///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//package entity;
//
///**
// *
// * @author Tuan Tran
// */
//public class BubbleSort {
//
//    /**
//     * Sắp xếp mảng theo thứ tự tăng dần
//     * bằng thuật toán Bubble Sort.
//     *
//     * @param array mảng cần sắp xếp
//     */
//    public static void sort(int[] array) {
//         // Kiểm tra mảng null hoặc chỉ có 1 phần tử
//        if (array == null || array.length <= 1) return;
//         // Lấy kích thước mảng
//        int n = array.length;
//        // Vòng lặp ngoài:
//        // sau mỗi lần lặp sẽ đưa phần tử lớn nhất
//        // về cuối mảng
//        for (int i = 0; i < n - 1; i++) {
//             // Vòng lặp trong:
//            // so sánh 2 phần tử liền kề
//            for (int j = 0; j < n - i - 1; j++) {
//                 // Nếu phần tử trước lớn hơn phần tử sau
//                if (array[j] > array[j + 1]) {
//                    // Swap array[j] and array[j+1]
//                    // Hoán đổi 2 phần tử
//                    int temp = array[j];
//                    array[j] = array[j + 1];
//                    array[j + 1] = temp;
//                }
//            }
//        }
//    }
//}