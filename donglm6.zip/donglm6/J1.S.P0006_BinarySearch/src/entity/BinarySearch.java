/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.util.Arrays;
import java.util.Random;

/**
 *
 * @author win
 */
public class BinarySearch {
// Mảng dùng để tìm kiếm

    private int[] array;

    /**
     * Hàm khởi tạo tạo mảng ngẫu nhiên.
     *
     * @param number kích thước mảng
     * @throws Exception nếu number <= 0
     */
    public BinarySearch(int number) throws Exception {
        // Kiểm tra kích thước mảng hợp lệ
        if (number <= 0) {
            throw new Exception("Number of array must be >0");
        }
        // Khởi tạo mảng
        array = new int[number];
        // Tạo đối tượng random
        Random random = new Random();
        // Sinh giá trị ngẫu nhiên từ -number đến number
        for (int i = 0; i < array.length; i++) {
//            array[i] = random.nextInt(number);
            array[i] = random.nextInt(number * 2 + 1) - number;
        }
    }

    /**
     * Hàm khởi tạo với mảng có sẵn.
     *
     * @param array mảng đầu vào
     * @throws Exception nếu mảng null
     */
    public BinarySearch(int[] array) throws Exception {
        // Kiểm tra mảng null
        if (array == null) {
            throw new Exception("Array can not null!");
        }
        this.array = array;
    }

    /**
     * Sắp xếp và hiển thị mảng.
     */
    public void display() {
        // Sắp xếp mảng tăng dần
        Arrays.sort(array);
        // In mảng ra màn hình
        System.out.println("Sorted array: " + Arrays.toString(array));
    }

    /**
     * Tìm kiếm giá trị bằng thuật toán Binary Search.
     *
     * @param key giá trị cần tìm
     * @return vị trí của key nếu tìm thấy, ngược lại trả về -1
     */
    public int binarySearch(int key) {
        // Biên trái
        int left = 0;
        // Biên phải
        int right = array.length - 1;
        // Lặp đến khi left vượt right
        while (left <= right) {
            // Tính vị trí giữa
            int mid = (left + right) / 2;
            // Nếu key lớn hơn phần tử giữa
            // tìm bên phải
            if (array[mid] < key) {
                left = mid + 1;
                // Nếu key nhỏ hơn phần tử giữa
                // tìm bên trái
            } else if (array[mid] > key) {
                right = mid - 1;
                // Nếu tìm thấy key
            } else {
                return mid;
            }
        }
        // Không tìm thấy
        return -1;
    }

    // NẾU THẦY YÊU CẦU Tìm TẤT CẢ vị trí của key thì code hàm dưới đây
    /**
     * Tìm tất cả vị trí của key trong mảng.
     *
     * @param key giá trị cần tìm
     * @return mảng chứa tất cả vị trí của key
     */
    public int[] binarySearchAll(int key) {
        // Tìm một vị trí của key trước
        int index = binarySearch(key);
        if (index == -1) {
            return new int[0]; // không tìm thấy
        }

        // tìm biên trái
        int left = index;
        while (left - 1 >= 0 && array[left - 1] == key) {
            left--;
        }

        // tìm biên phải
        int right = index;
        while (right + 1 < array.length && array[right + 1] == key) {
            right++;
        }

        // lưu tất cả vị trí
        int[] result = new int[right - left + 1];
        int idx = 0;
        // Lưu tất cả vị trí vào mảng kết quả
        for (int i = left; i <= right; i++) {
            result[idx++] = i;
        }

        return result;
    }
}
