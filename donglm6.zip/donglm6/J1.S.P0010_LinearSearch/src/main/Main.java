/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import entity.Array;
import java.util.Arrays;
import utils.Validator;

/**
 *
 * @author win
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         // Nhập số phần tử của mảng (n > 0)
        int number = Validator.getInt("Enter number of array: ",
                "Number must be >0", "Invalid!", 1, Integer.MAX_VALUE);
        Array array = null;
        try {
            // Khởi tạo mảng ngẫu nhiên gồm n phần tử
            array = new Array(number);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
            // Hiển thị mảng trước khi nhập giá trị cần tìm

        array.display(); //Thầy yêu cầu phải in mảng ra trước mới nhập key tìm kiếm
         // Nhập giá trị cần tìm kiếm
        int key = Validator.getInt("Enter search value: ",
                "Error range!", "Invalid!", Integer.MIN_VALUE, Integer.MAX_VALUE);
         // Tìm tất cả vị trí xuất hiện của giá trị cần tìm
        int index2[] = array.findAllIndex(key);
        // Hiển thị kết quả tìm kiếm
        if (index2.length == 0) {
            System.out.println("Can not found");
        } else {
            System.out.println("Found " + key + " at index: " + Arrays.toString(index2));
        }
    }

}
