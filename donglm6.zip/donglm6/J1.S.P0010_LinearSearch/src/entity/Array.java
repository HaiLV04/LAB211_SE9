/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

/**
 *
 * @author win
 */
public class Array {
    // Mảng số nguyên lưu dữ liệu

    private int[] array;

    /**
     * Khởi tạo một mảng có kích thước cho trước và sinh ngẫu nhiên các phần tử
     * trong mảng.
     *
     * @param number số phần tử của mảng
     * @throws Exception nếu số phần tử nhỏ hơn hoặc bằng 0
     */
    public Array(int number) throws Exception {
        // Kiểm tra số phần tử hợp lệ
        if (number <= 0) {
            throw new Exception("Number of array must be >0");
        }
        // Khởi tạo mảng với số phần tử được chỉ định

        array = new int[number];
        Random random = new Random();
        // Sinh giá trị ngẫu nhiên cho từng phần tử
        for (int i = 0; i < array.length; i++) {
            array[i] = random.nextInt(number);
        }
    }

    /**
     * Khởi tạo đối tượng Array từ một mảng có sẵn.
     *
     * @param array mảng đầu vào
     * @throws Exception nếu mảng đầu vào là null
     */
    public Array(int[] array) throws Exception {
        // Kiểm tra mảng đầu vào không được null

        if (array == null) {
            throw new Exception("Array can not null!");
        }
        this.array = array;
    }

    /**
     * Hiển thị toàn bộ các phần tử của mảng ra màn hình.
     */
    public void display() {
        System.out.println("The array: " + Arrays.toString(array));
    }

    /**
     * Thực hiện tìm kiếm tuần tự (Linear Search) để tìm vị trí xuất hiện đầu
     * tiên của giá trị cần tìm trong mảng.
     *
     * @param key giá trị cần tìm kiếm
     * @return vị trí đầu tiên chứa key, trả về -1 nếu không tìm thấy
     */
    public int linearSearch(int key) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == key) {
                return i;
            }
        }
        // Không tìm thấy giá trị cần tìm
        return -1;
    }

    /**
     * Tìm tất cả vị trí xuất hiện của giá trị cần tìm trong mảng.
     *
     * @param key giá trị cần tìm kiếm
     * @return mảng chứa tất cả chỉ số (index) tìm được, trả về mảng rỗng nếu
     * không tìm thấy
     */
    public int[] findAllIndex(int key) {
        ArrayList<Integer> indexList = new ArrayList<>();
        // Lưu tất cả vị trí có giá trị bằng key
        for (int i = 0; i < array.length; i++) {
            if (array[i] == key) {
                indexList.add(i);
            }
        }
        // Chuyển ArrayList thành mảng int[]
        int[] indices = new int[indexList.size()];
        for (int i = 0; i < indexList.size(); i++) {
            indices[i] = indexList.get(i);
        }
        return indices;
    }
}
