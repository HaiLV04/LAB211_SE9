package utils;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/**
 * Lớp MyUtils chứa các phương thức hỗ trợ cho chương trình, bao gồm nhập dữ
 * liệu, tạo mảng ngẫu nhiên và hiển thị mảng.
 *
 * @author Admin
 */
public class MyUtils {
    // Đối tượng Scanner dùng để nhập dữ liệu từ bàn phím

    private static final Scanner scanner = new Scanner(System.in);

    /**
     * Nhập một số nguyên dương từ bàn phím.
     *
     * Phương thức sẽ liên tục yêu cầu người dùng nhập lại cho đến khi nhập đúng
     * một số nguyên lớn hơn 0.
     *
     * @return số nguyên dương hợp lệ
     */
    public static int inputPositiveNumber() {
        while (true) {
            // Lặp cho đến khi người dùng nhập đúng
            try {
                System.out.print("Enter an integer number: ");
                String input = scanner.nextLine().trim();
                int number = Integer.parseInt(input);
                // Kiểm tra số nhập có lớn hơn 0 hay không
                if (number > 0) {
                    return number;

                } else {
                    System.out.println("Please input positive number > 0!");
                }
                // Xử lý trường hợp nhập không phải số nguyên
            } catch (NumberFormatException e) {
                System.out.println("Please input positive number!");
            }

        }

    }

    /**
     * Tạo mảng số nguyên ngẫu nhiên.
     *
     * Các phần tử của mảng có giá trị trong khoảng từ -n đến n.
     *
     * @param n kích thước của mảng
     * @return mảng số nguyên ngẫu nhiên
     */
    public static int[] generateRandom(int n) {
        // Tạo mảng có n phần tử
        int[] array = new int[n];
        Random random = new Random();
        for (int i = 0; i < n; i++) {
            // Sinh ngẫu nhiên từng phần tử trong khoảng -n đến n
            array[i] = random.nextInt(2 * n + 1) - n;
        }
        return array;
    }

    /**
     * Hiển thị các phần tử của mảng.
     *
     * @param array mảng cần hiển thị
     */

    public static void displayArray(int[] array) {
        System.out.println(Arrays.toString(array));
    }

}
