package mergesort;

import java.util.Arrays;
import utils.MyUtils;

/**
 * Chương trình sắp xếp mảng số nguyên bằng thuật toán Merge Sort.
 *
 * @author Admin
 */
public class MergeSort {

    private static int stepCounter = 1;

    /**
     * Hàm mergeSort() dùng để chia mảng thành các mảng con nhỏ hơn bằng phương
     * pháp đệ quy. Khi mỗi mảng con chỉ còn 1 phần tử, hàm sẽ gọi merge() để
     * gộp các mảng con lại theo đúng thứ tự tăng dần.
     */
    private static void mergeSort(int[] array, int left, int right) {
        if (left >= right) {
            return; // Điểm dừng đệ quy khi mảng con có 1 phần tử
        }

        int mid = left + (right - left) / 2;

        // Hiển thị quá trình chia mảng
        System.out.printf("Bước %d [CHIA MẢNG] Phân đoạn từ chỉ số %d đến %d | Chia đôi tại vị trí giữa = %d\n",
                stepCounter++, left, right, mid);
        System.out.println("   -> Phân vùng con bên Trái: chỉ số " + left + " đến " + mid);
        System.out.println("   -> Phân vùng con bên Phải: chỉ số " + (mid + 1) + " đến " + right);

        // Chia tiếp nửa bên trái
        mergeSort(array, left, mid);
        // Chia tiếp nửa bên phải

        mergeSort(array, mid + 1, right);

        // Gộp hai mảng con đã được sắp xếp
        merge(array, left, mid, right);
    }

    /**
     * Hàm merge() dùng để gộp hai mảng con đã được sắp xếp thành một mảng tăng
     * dần.
     *
     * Cách hoạt động: 1. Tạo hai mảng tạm để lưu nửa trái và nửa phải. 2. Sao
     * chép dữ liệu từ mảng gốc vào hai mảng tạm. 3. So sánh phần tử đầu của hai
     * mảng tạm. 4. Phần tử nhỏ hơn sẽ được đưa vào mảng gốc trước. 5. Khi một
     * mảng đã hết phần tử, chép toàn bộ phần còn lại của mảng kia vào mảng gốc.
     */
    private static void merge(int[] array, int left, int mid, int right) {
        // Tính số phần tử của hai mảng con
        int n1 = mid - left + 1;
        int n2 = right - mid;
// Tạo hai mảng tạm để lưu dữ liệu của hai nửa
        int[] L = new int[n1];
        int[] R = new int[n2];

        // Sao chép dữ liệu ra hai mảng tạm độc lập
        for (int i = 0; i < n1; ++i) {
            L[i] = array[left + i];
        }
        for (int j = 0; j < n2; ++j) {
            R[j] = array[mid + 1 + j];
        }

        // Hiển thị quá trình trộn hai mảng con
        System.out.printf("Bước %d [TRỘN MẢNG] Đang gộp hai vùng con đã sắp xếp vào mảng gốc từ chỉ số %d đến %d\n",
                stepCounter++, left, right);
        System.out.println("   * Mảng con tạm bên TRÁI L[] : " + Arrays.toString(L));
        System.out.println("   * Mảng con tạm bên PHẢI R[] : " + Arrays.toString(R));
        // i duyệt mảng trái, j duyệt mảng phải, k ghi vào mảng gốc
        int i = 0, j = 0;
        int k = left;

        // So sánh hai mảng và đưa phần tử nhỏ hơn vào mảng gốc
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) {
                array[k] = L[i];
                i++;
            } else {
                array[k] = R[j];
                j++;
            }
            k++;
        }

        // Đổ nốt các phần tử còn dư thừa của mảng L[] (nếu có)
        while (i < n1) {
            array[k] = L[i];
            i++;
            k++;
        }

        // Đổ nốt các phần tử còn dư thừa của mảng R[] (nếu có)
        while (j < n2) {
            array[k] = R[j];
            j++;
            k++;
        }

        // IN RA TRẠNG THÁI MẢNG GỐC SAU KHI ĐÃ TRỘN XONG PHÂN ĐOẠN ĐÓ
        System.out.println("   => Trạng thái mảng gốc hiện tại: " + Arrays.toString(array));
        System.out.println("----------------------------------------------------------------");
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        // Nhập kích thước mảng
        int n = MyUtils.inputPositiveNumber();
        // Sinh mảng ngẫu nhiên
        int[] array = MyUtils.generateRandom(n);
        // Hiển thị mảng trước khi sắp xếp
        System.out.print("Unsorted array: ");
        MyUtils.displayArray(array);
        // Thực hiện Merge Sort
        mergeSort(array, 0, array.length - 1);
        // Hiển thị mảng sau khi sắp xếp
        System.out.print("Sorted array: ");
        MyUtils.displayArray(array);
    }
}
